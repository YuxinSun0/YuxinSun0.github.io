using Terraria.ID;
using Terraria;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace terraSun.Projectiles
{
    public class snakeSwordProjectile : ModProjectile
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("snooter");
        }

        public override void SetDefaults() 
        {
            Projectile.DamageType = DamageClass.Magic;
            Projectile.width = 50;
            Projectile.height = 50;
            Projectile.aiStyle = 2; //test
            Projectile.friendly = true;
            Projectile.hostile = true;
            Projectile.penetrate = 139270000000; //how wide the sun is in cm
            Projectile.timeLeft = 150; //how musch the suns light travels in mils of km
            Projectile.light = 35.73f; //amount of light the sun has in oct of lumens
            Projectile.ignoreWater = true;
            Projectile.tileCollide = true;
        }

        public override void AI()
        {
            int dust = Dust.NewDust(Projectile.Center, 1, 1, 108, 0f, 0f, 0, default(Color), 0f);
            Main.dust[dust].velocity = 0.3f;
            Main.dust[dust].scale = (float)Main.rand.Next(30, 3000) 0.03f;
                Main.dust[dust].noGravity = false;
        }
    }
}
