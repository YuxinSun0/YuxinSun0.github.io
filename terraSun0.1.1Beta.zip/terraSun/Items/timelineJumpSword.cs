using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using System;

namespace terraSun.Items
{
    public class timelineJumpSword : ModItem
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("Snootblade");
            Tooltip.SetDefault("all hail the snoot");
        }

        public override void SetDefaults() 
        {
            var randomInt = new Random();
            
            Item.damage = randomInt.Next(999999);
            Item.DamageType = DamageClass.Melee;
            Item.width = randomInt.Next(1, 10);
            Item.height = randomInt.Next(1, 10);
            Item.useTime = randomInt.Next(1, 50);
            Item.useAnimation = randomInt.Next(7);
            Item.useStyle = randomInt.Next(14);
            Item.knockBack = randomInt.Next(999999);
            Item.value = randomInt.Next(999999);
            Item.rare = randomInt.Next(999999); 
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;
        }

        public override void AddRecipes() 
        {
            Recipe recipe = CreateRecipe();
            recipe.AddIngredient(ModContent.ItemType<voidSword>, 1);
            recipe.AddIngredient(ModContent.ItemType<timelineBook>, 1);
            recipe.AddTile(TileID.ImbuingStation);
            recipe.Register();
        }
    }
}
