using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace terraSun.Items
{
    public class meteorite : ModItem
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("METEORITE");
            Tooltip.SetDefault("A mysterious stone that flew in from outer space.\nIt's origin is not in the Milky Way.");
        }

        public override void SetDefaults() 
        {
            Item.width = 8;
            Item.height = 8;
            Item.value = 17000;
            Item.rare = 17000;
        }
    }
}
