using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace terraSun.Items
{
    public class snakeBone : ModItem
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("Snake Bone");
            Tooltip.SetDefault("The spine of a snake.");
        }

        public override void SetDefaults() 
        {
            Item.width = 10;
            Item.height = 2;
            Item.value = 200;
            Item.rare = 200;
        }
    }
}
