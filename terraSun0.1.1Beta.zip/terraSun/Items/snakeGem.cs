using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace terraSun.Items
{
    public class snakeGem : ModItem
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("SNAKE GEM");
            Tooltip.SetDefault("A magical gem rarely found inside snakes head.");
        }

        public override void SetDefaults() 
        {
            Item.width = 3;
            Item.height = 2;
            Item.value = 20000;
            Item.rare = 20000;
        }
    }
}
