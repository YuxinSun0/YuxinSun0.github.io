using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace terraSun.Items
{
    public class fistOfTheSun : ModItem
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("...?");
            Tooltip.SetDefault("A glove that...???");
        }

        public override void SetDefaults() 
        {
            Item.damage = 0;
            Item.DamageType = DamageClass.Melee;
            Item.width = 5;
            Item.height = 5;
            Item.useTime = 1;
            Item.useAnimation = 1;
            Item.useStyle = 13;
            Item.knockBack = 0;
            Item.value = 666;
            Item.rare = 666;
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = false;
        }
    }
}
