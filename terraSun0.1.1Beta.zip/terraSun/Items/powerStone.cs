using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace terraSun.Items
{
    public class meteorite : ModItem
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("POWER STONE");
            Tooltip.SetDefault("A powerful stone made of SPECIAL items.");
        }

        public override void SetDefaults() 
        {
            Item.width = 13;
            Item.height = 13;
            Item.value = 300000000;
            Item.rare = 300000000;
        }

        public override void AddRecipes() 
        {
            Recipe recipe = CreateRecipe();
            recipe.AddIngredient(ModContent.ItemType<voidGlove>, 1);
            recipe.AddIngredient(ModContent.ItemType<sunStone>, 3);
            recipe.AddIngredient(ModContent.ItemType<meteorite>, 3);
            recipe.AddTile(TileID.WorkBenches);
            recipe.Register();
        }
    }
}
