using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace terraSun.Items
{
    public class sunStone : ModItem
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("SUN STONE");
            Tooltip.SetDefault("Stone infused with the energy of the sun.");
        }

        public override void SetDefaults() 
        {
            Item.width = 4;
            Item.height = 4;
            Item.value = 200000;
            Item.rare = 200000;
        }
    }
}
