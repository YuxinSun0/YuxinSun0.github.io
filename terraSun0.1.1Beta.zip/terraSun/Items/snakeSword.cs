using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using terraSun.Projectiles;
using terraSun.Items;

namespace terraSun.Items
{
    public class snakeSword : ModItem
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("Snootblade");
            Tooltip.SetDefault("all hail the snoot");
        }

        public override void SetDefaults() 
        {
            Item.damage = 696969;
            Item.DamageType = DamageClass.Melee;
            Item.width = 6969;
            Item.height = 6969;
            Item.useTime = 6;
            Item.useAnimation = 9;
            Item.useStyle = 1;
            Item.knockBack = 69;
            Item.value = 696969;
            Item.rare = 69; 
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;
            Item.shoot = ModContent.ProjectileType<snakeSwordProjectile>();
        }

        public override void AddRecipes() 
        {
            Recipe recipe = CreateRecipe();
            recipe.AddIngredient(ModContent.ItemType<snakeBone>, 999);
            recipe.AddIngredient(ModContent.ItemType<snakeGem>, 600);
            recipe.AddTile(TileID.WorkBenches);
            recipe.Register();
        }
    }
}
