using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace terraSun.Items
{
    public class timelineBook : ModItem
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("BOOK OF TIME");
            Tooltip.SetDefault("A version of the Book of Time about the TIMELINES.");
        }

        public override void SetDefaults() 
        {
            Item.width = 6;
            Item.height = 6;
            Item.value = 99999;
            Item.rare = 99999;
        }
    }
}
