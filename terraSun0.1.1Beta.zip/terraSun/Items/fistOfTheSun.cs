using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using terraSun.Projectiles;
using terraSun.Items;

namespace terraSun.Items
{
    public class fistOfTheSun : ModItem
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("FIST OF THE SUN");
            Tooltip.SetDefault("A magical glove crafted out of meteorite.\nIt contains the energy of the sun.");
        }

        public override void SetDefaults() 
        {
            Item.damage = 2740000;
            Item.DamageType = DamageClass.Melee;
            Item.width = 4;
            Item.height = 4;
            Item.useTime = 1;
            Item.useAnimation = 1; //test
            Item.useStyle = 13;
            Item.knockBack = 279;
            Item.value = 3400000000;
            Item.rare = 3400000000;
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = false;
            Item.shoot = ModContent.ProjectileType<fistOfTheSunAirFistProjectile>();
        }

        public override void AddRecipes() 
        {
            Recipe recipe = CreateRecipe();
            recipe.AddIngredient(ModContent.ItemType<powerStone>, 1)
            recipe.AddTile(TileID.Anvils);
            recipe.Register();
        }
    }
}
