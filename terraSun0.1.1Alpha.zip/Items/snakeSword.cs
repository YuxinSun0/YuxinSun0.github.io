using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using terraSun.Projectiles;

namespace terraSun.Items
{
    public class snakeSword : ModItem
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("Snootblade");
            Tooltip.SetDefault("all hail the snoot");
        }

        public override void SetDefaults() 
        {
            Item.damage = 6969;
            Item.DamageType = DamageClass.Melee;
            Item.width = 69;
            Item.height = 69;
            Item.useTime = 6;
            Item.useAnimation = 6;
            Item.useStyle = 1;
            Item.knockBack = 69;
            Item.value = 696969;
            Item.rare = 69; 
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;
            Item.shoot = ModContent.ProjectileType<snakeSwordProjectile>();
        }

        public override void AddRecipes() 
        {
            Recipe recipe = CreateRecipe();
            recipe.AddIngredient(ItemID.DirtBlock, 69);
            recipe.AddTile(TileID.WorkBenches);
            recipe.Register();
        }
    }
}
