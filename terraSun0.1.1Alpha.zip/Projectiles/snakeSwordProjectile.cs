using Terraria.ID;
using Terraria;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace terraSun.Projectiles
{
    public class snakeSwordProjectile : ModProjectile
    {
        public override void SetStaticDefaults() 
        {
            DisplayName.SetDefault("snooter");
        }

        public override void SetDefaults() 
        {
            Projectile.DamageType = DamageClass.Magic;
            Projectile.width = 69;
            Projectile.height = 69;
            Projectile.aiStyle = 9;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.penetrate = 6969;
            Projectile.timeLeft = 690;
            Projectile.light = 1.69f;
            Projectile.ignoreWater = true;
            Projectile.tileCollide = false;
        }

        public override void AI()
        {
            int dust = Dust.NewDust(Projectile.Center, 1, 1, Main.rand.Next(-1, 269), 0f, 0f, 0, default(Color), 69f);
            Main.dust[dust].velocity *= 0.69f;
            Main.dust[dust].scale = (float)Main.rand.Next(69, 6969) 0.069f;
            if (Main.rand.Next(1) == 0) {
                Main.dust[dust].noGravity = true;
            } else {
                Main.dust[dust].noGravity = false;
            }
        }
    }
}
