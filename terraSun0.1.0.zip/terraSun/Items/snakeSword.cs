using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace terraSun.Items
{
    public class snakeSword : ModItem
    {
        public override void SetStaticDefaults() 
		{
			DisplayName.SetDefault("snoot blade");
			Tooltip.SetDefault("all hail snoot");
        }

        public override void SetDefaults() 
		{
			Item.damage = 69;
			Item.DamageType = DamageClass.Melee;
			Item.width = 69;
			Item.height = 69;
			Item.useTime = 20;
			Item.useAnimation = 20;
			Item.useStyle = 1;
			Item.knockBack = 69;
			Item.value = 696969;
			Item.rare = 69; 
			Item.UseSound = SoundID.Item1;
			Item.autoReuse = true;
		}

        public override void AddRecipes() 
		{
			Recipe recipe = CreateRecipe();
			recipe.AddIngredient(ItemID.DirtBlock, 69);
			recipe.AddTile(TileID.WorkBenches);
			recipe.Register();
		}
    }
}