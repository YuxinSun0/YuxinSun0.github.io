using Terraria.ModLoader;

namespace terraSun
{
	public class terraSun : Mod
	{
	}
}